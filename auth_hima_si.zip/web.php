<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AdminAuthController;
use App\Http\Controllers\Auth\MahasiswaAuthController;

// ── Halaman Publik ────────────────────────────────────────────────────────────
Route::get('/', function () {
    return view('welcome');
})->name('home');

// ── Auth Admin ────────────────────────────────────────────────────────────────
Route::prefix('admin')->name('admin.')->group(function () {

    // Login (guest only)
    Route::middleware('guest')->group(function () {
        Route::get('/login',  [AdminAuthController::class, 'showLoginForm'])->name('login');
        Route::post('/login', [AdminAuthController::class, 'login'])->name('login.post');
    });

    Route::post('/logout', [AdminAuthController::class, 'logout'])->name('logout');

    // Protected admin routes
    Route::middleware('admin')->group(function () {
        Route::get('/dashboard', function () {
            return view('admin.dashboard');
        })->name('dashboard');

        // Super Admin only
        Route::middleware('superadmin')->prefix('super')->name('super.')->group(function () {
            Route::get('/akun', function () {
                return 'Kelola akun admin — coming soon';
            })->name('akun');
        });
    });
});

// ── Auth Mahasiswa ────────────────────────────────────────────────────────────
Route::middleware('guest')->group(function () {
    Route::get('/login',  [MahasiswaAuthController::class, 'showLoginForm'])->name('mahasiswa.login');
    Route::post('/login', [MahasiswaAuthController::class, 'login'])->name('mahasiswa.login.post');
});

Route::post('/logout', [MahasiswaAuthController::class, 'logout'])->name('mahasiswa.logout');

// Ganti password first-login (perlu login tapi tidak perlu password_changed)
Route::middleware('mahasiswa_auth')->prefix('portal')->name('mahasiswa.')->group(function () {

    Route::get('/ganti-password',  [MahasiswaAuthController::class, 'showChangePasswordForm'])->name('password.change');
    Route::post('/ganti-password', [MahasiswaAuthController::class, 'changePassword'])->name('password.update');

    // Protected portal routes (password sudah diganti)
    Route::get('/dashboard', function () {
        return view('mahasiswa.dashboard');
    })->name('dashboard');
});
