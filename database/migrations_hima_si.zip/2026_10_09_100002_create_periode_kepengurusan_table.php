<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('periode_kepengurusan', function (Blueprint $table) {
            $table->id();
            $table->string('nama', 20);
            $table->year('tahun_mulai');
            $table->year('tahun_selesai');
            $table->enum('status', ['aktif', 'arsip'])->default('arsip');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('periode_kepengurusan');
    }
};
